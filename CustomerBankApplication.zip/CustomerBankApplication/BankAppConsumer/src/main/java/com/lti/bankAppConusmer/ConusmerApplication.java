package com.lti.bankAppConusmer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.lti.bankAppConusmer.controller.CustomerController;


@SpringBootApplication
public class ConusmerApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(ConusmerApplication.class, args);
		CustomerController consumerController=ctx.getBean(CustomerController.class);
		System.out.println(consumerController);
		consumerController.getCustomer();
	}

}
