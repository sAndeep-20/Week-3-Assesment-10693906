package com.lti.eurekaConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
